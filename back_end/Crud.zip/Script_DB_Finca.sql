create database FINCA_INV;
use FINCA_INV;

create table usuario (
id int primary key not null identity(1,1),
nombre varchar(10),
contrase�a int,
correo varchar(30)
);

create table empleado (
id_empleado int primary key not null identity(1,1),
nombre varchar(10),
apellido varchar(20),
cargo varchar(20),
correo varchar(30),
);

create table huerto (
id_huerto int primary key not null identity(1,1),
tipo_planta varchar(10),
estado varchar(20),
tama�o_poblacion int,
ubicacion varchar(20),
descripcion varchar(100),
);

create table implementos (
id_implemento int primary key not null identity(1,1),
nombre varchar(20),
tipo varchar(20),
descripcion varchar(200),
ubicacion varchar(20),
);

create table herramientas (
id_herramienta int primary key not null identity(1,1),
nombre varchar(20),
area varchar(20),
tipo varchar(20),
existencia int,
localizacion varchar(20)
);

create table lubricantes (
id_lubricante int primary key not null identity(1,1),
nombre varchar(20),
tipo varchar(20),
marca varchar(20),
);

create table maquinaria(
id_maquina int primary key not null identity(1,1),
nombre varchar(20),
n_serie int,
matricula varchar(10),
modelo int,
marca varchar(10),
tipo_combustible varchar(10),
tipo_lubricante int,
foreign key (tipo_lubricante) references lubricantes(id_lubricante)
);

create table operaciones_agricolas (
id_operacion int primary key not null identity(1,1),
encargado int,
tipo_cultivo varchar(20),
etapa varchar(20),
fecha_ini date,
fecha_fin date,
observaciones text,
foreign key (encargado) references empleado(id_empleado)
);

create table productos (
id_producto int primary key not null identity(1,1),
huerto int,
nombre_producto varchar(20),
tipo varchar(20),
modo_uso text,
existencia int,
foreign key (huerto) references huerto(id_huerto)
);

create table mantenimiento_maquinaria (
id_mant_maquina int primary key not null identity(1,1),
maquina int,
fecha_mantenimiento date,
tipo_mantenimiento varchar(50),
descripcion_mantenimiento text,
responsable int,
observaciones text
foreign key (maquina) references maquinaria(id_maquina),
foreign key (responsable) references empleado(id_empleado),
);

create table mantenimiento_implementos (
id_mant_implemento int primary key not null identity(1,1),
implemento int,
fecha_mantenimiento date,
tipo_mantenimiento varchar(50),
descripcion_mantenimiento text,
responsable int,
observaciones text,
foreign key (implemento) references implementos(id_implemento),
foreign key (responsable) references empleado(id_empleado),
);


alter table empleado alter column correo varchar(30)
alter table usuario alter column correo varchar(30)